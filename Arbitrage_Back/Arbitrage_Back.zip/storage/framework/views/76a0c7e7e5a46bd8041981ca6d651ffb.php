<?php echo e($slot); ?>

<?php /**PATH C:\D\Projetes\Arbitregae_2\Arbitrage_Back\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>