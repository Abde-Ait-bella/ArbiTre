<?php echo e($slot); ?>

<?php /**PATH C:\D\Projetes\Arbitre\Arbitrage_Back\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>