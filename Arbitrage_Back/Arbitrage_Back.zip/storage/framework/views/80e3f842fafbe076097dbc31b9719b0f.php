<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\D\Projetes\Arbitre\Arbitrage_Back\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>