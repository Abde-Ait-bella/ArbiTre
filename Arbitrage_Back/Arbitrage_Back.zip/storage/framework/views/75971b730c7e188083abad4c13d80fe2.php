<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\D\Projetes\Arbitre\Arbitrage_Back\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>