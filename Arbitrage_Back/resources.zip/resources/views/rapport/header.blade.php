  <table class="images row print-header" style="width: 100%; border-collapse: collapse; margin-bottom: 20px; border: none;">
            <tr style="border: none;">
                <td style="width: 20%; text-align: center; vertical-align: middle; border: none;">
                    <img 
                        class="logoLigue" 
                        src="{{ public_path('images/frmf.png') }}" 
                        alt="ligue souss" 
                        style="height: 100px; width: auto;"
                    />
                </td>
                <td style="width: 30%; text-align: center; vertical-align: middle; border: none;">
                    <div class="mb-0 text-center">
                        <p style="margin: 0; font-size: 20px; font-weight: bold;">الجامعة الملكية المغربية لكرة القدم</p>
                        <p style="margin: 0; font-size: 16px;">العصبة الجهوية سوس ماسة لكرة القدم</p>
                        <p style="margin: 0; font-size: 14px;">اللجنة الجهوية للتحكيم - المديرية الجهوية للحكام</p>
                    </div>
                </td>
                <td style="width: 30%; text-align: center; vertical-align: middle; border: none;">
                    <div class="mb-0 text-center">
                        <p style="margin: 0; font-size: 20px; font-weight: bold;">Fédération royale marocaine de football</p>
                        <p style="margin: 0; font-size: 16px;">Ligue Régionale de Souss Massa de football</p>
                        <p style="margin: 0; font-size: 14px;">Comité Régional d'Arbitrage - Direction Régionale de l'Arbitrage</p>
                    </div>
                </td>
                <td style="width: 20%; text-align: center; vertical-align: middle; border: none;">
                    <img 
                        class="titleLigue" 
                        src="{{ public_path('images/ligue_souss.png') }}" 
                        alt="ligue souss" 
                        style="height: 100px; width: auto;"
                    />
                </td>
            </tr>
        </table>